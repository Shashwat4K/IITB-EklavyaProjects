/**
 * Created by anishkelkar on 23/3/17.
 */
var mySceneTLX;        /* Top Left corner X coordinate */
var mySceneTLY;        /* Top Left corner Y coordinate */
var mySceneBRX;        /* Bottom Right corner X coordinate */
var mySceneBRY;        /* Bottom Right corner Y coordinate */
var mySceneW;          /* Scene Width */
var mySceneH;          /* Scene Height */
var myCenterX;         /* Scene Center X coordinate */
var myCenterY;

var canvas;
var geometry;
var material;

var body;

var tbl;
var digits=[];
var tblbody;
var row;
var cell1,cell2;
var inp;

var fracTbl;
var fracTblBody;
var fracRow,fracRow2;
var fc11,fc12,fc21,fc22;

//var rel = new Array();
var headerRow=["Number","Ten-thousand","Thousands","Hundreds","Tens","Units","One-tenth","One-hundredth"];

function gcd( a, b){
    if(b==0){
        return a;
    }
    else{
        return gcd(b,a%b);
    }

}

function createCanvas()
{
    geometry= new THREE.PlaneBufferGeometry(mySceneW+3,mySceneH+2);
    material= new THREE.MeshBasicMaterial({color:0xdddd00});
    canvas= new THREE.Mesh(geometry,material);
    canvas.position.set(myCenterX,myCenterY,-1);
    PIEaddElement(canvas);
    /** input
     *
     * @type {Element}
     */
    /**
    decimalNumberInput=document.createElement("INPUT");
    decimalNumberInput.setAttribute("id","Ipt");
    decimalNumberInput.style.position="absolute";
    decimalNumberInput.style.left="36%";
    decimalNumberInput.style.top="20%";
    decimalNumberInput.style.width="7.5%";
    decimalNumberInput.style.height="3.75%";
    decimalNumberInput.type="float";
     */
    /**
     *   Text element
     */
    /**
    decimalNum=document.createElement("TABLE");
    decimalNum.setAttribute("id","cell");
    decimalNum.style.width = '12.5%';
    decimalNum.setAttribute('border', '1');
    document.body.appendChild(decimalNumberInput);
    document.body.appendChild(decimalNum);
    var y=document.createElement("TR");
    //document.getElementById("cell").appendChild(y);
    var z=document.createElement("TD");
    var z2=document.createElement("TD");
    var t=document.createElement("body");
    t.innerHTML="Insert the value";
    //z.style.border="1px solid #000000";
    z.appendChild(t);
    y.appendChild(z);
    decimalNum.style.position="absolute";
    decimalNum.style.left="25%";
    decimalNum.style.top="20%";
    decimalNum.style.border="1px solid #000000";
    document.getElementById("cell").appendChild(y);
    */
    /*
        z=null;
        z=document.createElement("TD");
        z.appendChild(decimalNumberInput);
        //z.style.border="1px solid #000000";
        y.appendChild(z);
    */
        //var body = document.getElementsByTagName('body')[0];
        /**
         decimalNum = document.createElement('table');
        decimalNum.style.width = '100%';
        decimalNum.setAttribute('border', '1');
        var tbdy = document.createElement('tbody');
        for (var i = 0; i < 3; i++) {
            var tr = document.createElement('tr');
            for (var j = 0; j < 2; j++) {
                if (i == 2 && j == 1) {
                    break
                } else {
                    var td = document.createElement('td');
                    td.appendChild(document.createTextNode('\u0020'))
                    i == 1 && j == 1 ? td.setAttribute('rowSpan', '2') : null;
                    tr.appendChild(td)
                }
            }
            tbdy.appendChild(tr);
        }
        decimalNum.appendChild(tbdy);
        document.body.appendChild(decimalNum);
         */
    }
    function createDisplayTable()
    {

        body=document.getElementsByTagName("body")[0];
        tbl=document.createElement('table');
        tblbody=document.createElement('tbody');
        row=document.createElement('tr');
        cell1=document.createElement('td');
        cell1.innerHTML="Decimal Input";
         cell2=document.createElement('td');
        inp=document.createElement("INPUT");
        inp.type='float';
        inp.value="";
        inp.width="15%";
        inp.setAttribute("id","decimal");
        cell2.appendChild(inp);
        row.appendChild(cell1);
        row.appendChild(cell2);
        tblbody.appendChild(row);
        tbl.appendChild(tblbody);
        body.appendChild(tbl);
        tbl.setAttribute('border','2');
        tbl.setAttribute('id','myTbl');
        tbl.style.position="absolute";
        tbl.style.left="35%";
        tbl.style.top="17.5%";
    }
    function setOtherTables()
    {
        fracTbl=document.createElement('table');
        fracTblBody=document.createElement('tbody');
        fracRow=document.createElement('tr');
        fracRow2=document.createElement('tr');
        fc11=document.createElement('td');
        fc11.innerHTML="Original Fraction";
        fc12=document.createElement('td');
        fc12.setAttribute("id","origval");
        fracRow.appendChild(fc11);
        fracRow.appendChild(fc12);
        fc21=document.createElement('td');
        fc21.innerHTML="Reduced Fraction";
        fc22=document.createElement('td');
        fc22.setAttribute("id","redval");
        fracRow2.appendChild(fc21);
        fracRow2.appendChild(fc22);
        fracTblBody.appendChild(fracRow);
        fracTblBody.appendChild(fracRow2);
        fracTbl.appendChild(fracTblBody);
        body.appendChild(fracTbl);
        fracTbl.setAttribute('border','2');
        fracTbl.setAttribute('id','myTbl');
        fracTbl.style.position="absolute";
        fracTbl.style.left="35%";
        fracTbl.style.top="25.5%";
    }
    function resetExperiment()
    {
        if(inp!=null) {
            inp.value = "";
        }
        for(var i=0;i<8;i++)
        {
            PIEupdateTableCell(1,i,0);
        }
        fc12.innerHTML="0/1";
        fc22.innerHTML="0/1";
    }
    function initialiseHelp()
    {

    }

    function initialiseInfo()
    {

    }
    function initialiseScene()
    {
        mySceneTLX = 0.0;
        mySceneTLY = 3.0;
        mySceneBRX = 4.0;
        mySceneBRY = 0.0;
        mySceneW   = (mySceneBRX - mySceneTLX);
        mySceneH   = (mySceneTLY - mySceneBRY);
        myCenterX  = (mySceneTLX + mySceneBRX) / 2.0;
        myCenterY  = (mySceneTLY + mySceneBRY) / 2.0;
        floatprev=null;
    }

    function loadExperimentElements()
    {
        PIEsetExperimentTitle("Decimal Places");
        PIEsetDeveloperName("Anish Kelkar");
        PIEhideControlElement();
        initialiseHelp();
        initialiseInfo();
        initialiseScene();
        createCanvas();
        createDisplayTable();
        setOtherTables();
        /*decimalNumberInput=PIEcreateTable("Table",10,5,false);
        decimalNumberInput=PIEcreateTableCell(1,1,false);
        */
        PIEcreateTable(" Decimal Places", 2, 8, true);
       PIEupdateTableRow(0,headerRow);
       PIEsetRowInput(1, 8, "");
        resetExperiment();
    PIEsetAreaOfInterest(mySceneTLX, mySceneTLY, mySceneBRX, mySceneBRY);
}

function updateExperimentElements()
{
    var val=document.getElementById("decimal");
    float=val.value;
    PIEupdateTableCell(1,0,float);


    var temp=float;
    var divide=10000;
    var i=1;
    var numerator=0;
    var denominator=1;
    var t;
    digits=[];
    while(i<=7)
    {
        if(i==7)
        {
            t=Math.floor(temp/10000);
            if(temp/10000-t>=0.5)
            {
                temp++;
            }
        }
        else
        {
            t=Math.floor(temp/10000);
        }
        digits.push(t);
        PIEupdateTableCell(1,i,t);
        temp-=(t*10000);
        temp*=10;
        i++;
    }
     i=6;
    while(i>=5)
    {
        if(digits[i]!=0)
        {
            if(denominator==1)
            {
                if(i==6)
                {
                    denominator=100;
                }
                else
                {
                    denominator=10;
                }
            }
        }
        i--;
    }
    i=0;
    numerator=0;
    if(denominator==100)
    {
        while(i<7)
        {
            numerator*=10;
            numerator+=digits[i];
            i++;

        }
    }
    else if(denominator==10)
    {
        while(i<6)
        {
            numerator*=10;
            numerator+=digits[i];
            i++;
        }
    }
    else
    {
        while(i<5)
        {
            numerator*=10;
            numerator+=digits[i];
            i++;
        }
    }
    var hcf=gcd(numerator,denominator);
    var redNum=numerator/hcf;
    var redDen=denominator/hcf;

    /*
    while(i<=8)
    {
        numerator*=10;
        if(numerator!=0)
        {
                if(denominator==0)
                {
                    denominator=10;
                }
                else
                {
                    denominator *= 10;
                }
        }
        else
        {
            if(i>5)
            {
                if(denominator==0)
                {
                    denominator=10;
                }
                else
                {
                    denominator *= 10;
                }
            }
        }


        numerator+=Math.floor(temp/divide);
        PIEupdateTableCell(1,i,Math.floor(temp/divide));
        temp-=(Math.floor(temp/divide)*divide);
        divide/=10;
        i++;
    }
    */
    var editOrig=document.getElementById("origval");
    if(denominator!=0)
    {
        editOrig.innerHTML=numerator+"/"+denominator;
    }
    else
    {
        editOrig.innerHTML="-";
    }
    var editRed=document.getElementById("redval");
    if(redDen==denominator || redNum==numerator)
    {
        editRed.innerHTML=numerator+"/"+denominator;
    }
    else
    {
        editRed.innerHTML=redNum+"/"+redDen;
    }
    /**
    while(Math.abs(temp-0)>0.0001) {
        var dig = Math.floor(temp / Math.pow(10, digMinPwr));
        temp -= Math.pow(10, digMinPwr) * dig;
        if (temp != 0) {
            digMinPwr--;
        }
    }
     */

    /*
    for(var i = digMaxPwr;i>=digMinPwr;i--)
    {
        headerRow.push(rel[i]);
        console.log(rel[i]);
    }*/

    /**
   var temp;
   temp=0;
    if(float>1000)
    {
        temp=Math.floor(float/1000);
        PIEupdateTableCell(1,1,temp);
        float-=temp*1000;
    }
    temp=0;
    if(float>100)
    {
        temp=Math.floor(float/100);
        PIEupdateTableCell(1,2,temp);
        float-=temp*100;
    }
   floatprev=float;
     */
}
